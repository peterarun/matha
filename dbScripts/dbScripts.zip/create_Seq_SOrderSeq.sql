USE [MathaNew]

GO

CREATE SEQUENCE [dbo].[SOrderSeq] 
 AS [int]
 MINVALUE 2784
 NO CACHE 

GO


