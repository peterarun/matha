USE [MathaNew]

GO

CREATE SEQUENCE [dbo].[SalesSerialSeq] 
 AS [int]
 MINVALUE 729
 NO CACHE 

GO


