USE [MathaNew]

GO

CREATE SEQUENCE [dbo].[SalesSeq] 
 AS [int]
 MINVALUE 2673
 NO CACHE 

GO


