USE [MathaNew]
GO

/****** Object:  Table [dbo].[ACCategory]    Script Date: 14-01-2018 20:49:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CashHead](
	[Id] [nvarchar](30) PRIMARY KEY,
	[Description] [nvarchar](100) NULL
) ON [PRIMARY]
GO


